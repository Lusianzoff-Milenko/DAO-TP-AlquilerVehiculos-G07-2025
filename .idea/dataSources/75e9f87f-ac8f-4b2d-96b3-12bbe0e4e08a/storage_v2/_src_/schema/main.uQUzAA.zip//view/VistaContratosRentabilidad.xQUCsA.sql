CREATE VIEW VistaContratosRentabilidad AS
SELECT
    CO.id AS Contrato_ID,
    V.patente AS Patente_Vehiculo,
    P_Cliente.nombre || ' ' || P_Cliente.apellido AS Nombre_Cliente,
    P_Empleado.nombre || ' ' || P_Empleado.apellido AS Empleado_Vendedor,
    CO.fecha_desde AS Fecha_Desde,
    CO.fecha_hasta AS Fecha_Hasta,
    DP.fecha_entrega AS Fecha_Real_Entrega,
    MDP.nombre AS Método_Pago,
    ES.nombre AS Estado_Contrato,
    DP.monto AS Monto_Contrato,
    CO.tiene_seguro AS Tiene_Seguro,
    SUM(RI.costo) AS Costo_Total_Inconvenientes
FROM
    Contrato CO
JOIN
    DetalleContrato DP ON CO.id = DP.id_contrato -- Nueva unión para obtener id_vehiculo
JOIN
    Vehiculo V ON DP.id_vehiculo = V.id
JOIN
    Cliente CL ON CO.id_cliente = CL.id
JOIN
    Persona P_Cliente ON CL.id_persona = P_Cliente.id
JOIN
    Empleado EM ON CO.id_empleado = EM.id
JOIN
    Persona P_Empleado ON EM.id_persona = P_Empleado.id
JOIN
    MetodoDePago MDP ON CO.id_metodoDePago = MDP.id
JOIN
    Estado ES ON CO.id_estado = ES.id -- Cambiado de estadoActual a id_estado
LEFT JOIN
    RegistroInconvenientes RI ON CO.id = RI.id_contrato
GROUP BY
    CO.id, V.patente, P_Cliente.nombre, P_Cliente.apellido, P_Empleado.nombre, P_Empleado.apellido,
    CO.fecha_desde, CO.fecha_hasta, DP.fecha_entrega, MDP.nombre, ES.nombre, DP.monto, CO.tiene_seguro;

