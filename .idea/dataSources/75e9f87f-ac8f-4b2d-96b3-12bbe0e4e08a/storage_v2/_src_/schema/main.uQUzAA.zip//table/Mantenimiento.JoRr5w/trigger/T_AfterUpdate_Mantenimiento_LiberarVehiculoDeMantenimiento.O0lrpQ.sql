CREATE TRIGGER T_AfterUpdate_Mantenimiento_LiberarVehiculoDeMantenimiento
AFTER UPDATE ON Mantenimiento
WHEN NEW.id_estado = 4 -- Si el mantenimiento se marca como 'Finalizado' (ID 4)
BEGIN
    UPDATE Vehiculo
    SET id_estado = 1 -- ID 1: 'Disponible'
    WHERE id = NEW.id_vehiculo;
END;

