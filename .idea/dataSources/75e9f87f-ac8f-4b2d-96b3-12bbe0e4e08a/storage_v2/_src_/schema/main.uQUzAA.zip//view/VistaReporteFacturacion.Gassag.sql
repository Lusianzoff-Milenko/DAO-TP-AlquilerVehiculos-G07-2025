CREATE VIEW VistaReporteFacturacion AS
SELECT
    CO.id AS Contrato_ID,
    V.patente AS Patente,
    P_Cliente.nombre || ' ' || P_Cliente.apellido AS Cliente,
    CO.fecha_desde AS Fecha_Inicio,
    CO.fecha_hasta AS Fecha_Fin_Esperada,
    DP.fecha_entrega AS Fecha_Entrega_Real,
    -- Calcular la duración del alquiler en días (solo si ha sido entregado)
    CASE 
        WHEN DP.fecha_entrega IS NOT NULL THEN (julianday(DP.fecha_entrega) - julianday(CO.fecha_desde)) 
        ELSE (julianday(CO.fecha_hasta) - julianday(CO.fecha_desde))
    END AS Dias_Alquilados,
    DP.monto AS Monto_Alquiler_Base,
    IFNULL(SUM(RI.costo), 0) AS Costo_Total_Inconvenientes,
    (DP.monto + IFNULL(SUM(RI.costo), 0)) AS Monto_Total_Facturado,
    E.nombre AS Estado_Contrato
FROM
    Contrato CO
JOIN
    DetalleContrato DP ON CO.id = DP.id_contrato
JOIN
    Vehiculo V ON CO.id_vehiculo = V.id
JOIN
    Cliente CL ON CO.id_cliente = CL.id
JOIN
    Persona P_Cliente ON CL.id_persona = P_Cliente.id
JOIN
    Estado E ON CO.id_estado = E.id
LEFT JOIN
    RegistroInconvenientes RI ON CO.id = RI.id_contrato
WHERE
    CO.id_estado = 4 -- Solo Contratos 'Finalizados' (ID 4) son facturados
GROUP BY
    CO.id, V.patente, P_Cliente.nombre, P_Cliente.apellido, CO.fecha_desde, CO.fecha_hasta, DP.fecha_entrega, DP.monto, E.nombre;

