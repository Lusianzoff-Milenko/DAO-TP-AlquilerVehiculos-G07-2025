CREATE TRIGGER T_AfterInsert_Mantenimiento_ActualizarVehiculoAMantenimiento
AFTER INSERT ON Mantenimiento
FOR EACH ROW
WHEN NEW.id_estado = 5 -- Si el mantenimiento registrado está 'Activo' (ID 5)
BEGIN
    UPDATE Vehiculo
    SET id_estado = 3 -- ID 3: 'En Mantenimiento'
    WHERE id = NEW.id_vehiculo;
END;

