CREATE VIEW VistaDemandaPorModelo AS
SELECT
    MA.nombre AS Marca,
    MO.nombre AS Modelo,
    MO.cantidad_pasajeros AS Cantidad_Pasajeros,
    MO.cantidad_puertas AS Cantidad_Puertas,
    MO.motor AS Motor,
    COUNT(CO.id) AS Total_Alquileres,
    IFNULL(
        SUM(julianday(CO.fecha_hasta) - julianday(CO.fecha_desde)), 
        0
    ) AS Total_Dias_Reservados_Contratados -- Demanda total (incluye contratos activos)
FROM
    Contrato CO
JOIN
    DetalleContrato DP ON CO.id = DP.id_contrato -- Nueva unión para obtener id_vehiculo
JOIN
    Vehiculo V ON DP.id_vehiculo = V.id
JOIN
    Modelo MO ON V.id_modelo = MO.id
JOIN
    Marca MA ON MO.id_marca = MA.id
GROUP BY
    MA.nombre, MO.nombre, MO.cantidad_pasajeros, MO.cantidad_puertas, MO.motor
ORDER BY
    Total_Dias_Reservados_Contratados DESC;

