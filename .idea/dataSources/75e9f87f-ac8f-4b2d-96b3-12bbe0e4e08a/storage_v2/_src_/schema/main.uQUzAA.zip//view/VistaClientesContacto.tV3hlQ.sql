CREATE VIEW VistaClientesContacto AS
SELECT
    C.id AS Cliente_ID,
    P.nombre AS Nombre,
    P.apellido AS Apellido,
    TD.nombre AS Tipo_Documento,
    C.documento AS Documento,
    P.fecha_nacimiento AS Fecha_Nacimiento,
    P.telefono AS Teléfono,
    P.mail AS Correo_Electrónico,
    P.direccion AS Dirección
FROM
    Cliente C
JOIN
    Persona P ON C.id_persona = P.id
JOIN
    TipoDocumento TD ON C.id_tipoDocumento = TD.id;

