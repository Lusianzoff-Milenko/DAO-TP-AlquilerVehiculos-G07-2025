CREATE TRIGGER T_AfterInsert_Contrato_ActualizarVehiculoAAlquilado
AFTER INSERT ON Contrato
FOR EACH ROW
BEGIN
    UPDATE Vehiculo
    SET id_estado = 2 -- ID 2: 'Alquilado'
    WHERE id = NEW.id_vehiculo;
END;

