CREATE VIEW VistaVehiculosDetallados AS
SELECT
    M.nombre AS Modelo,
    MA.nombre AS Marca,
    C.nombre AS Color,
	V.patente AS Patente,
    F.foto_path AS Foto,
    V."año_fabricacion" AS "Año", -- Asumimos año_lanzamiento = año_fabricacion
    M.cantidad_puertas AS Cantidad_Puertas,
    M.cantidad_pasajeros AS Cantidad_Pasajeros,
    V.precio_base AS Precio_Base,
    E.nombre AS Estado_Vehiculo
FROM
    Vehiculo V
JOIN
    Modelo M ON V.id_modelo = M.id
JOIN
    Marca MA ON M.id_marca = MA.id
JOIN
    Color C ON V.color = C.id
LEFT JOIN
    FotoXModelo F ON V.id_modelo = F.id_modelo
                 AND V.color = F.id_color
                 AND V."año_fabricacion" = F."año_fabricacion" -- Filtra la foto por el mismo año
JOIN
    Estado E ON V.id_estado = E.id;

