CREATE VIEW VistaDisponibilidadFlota AS
SELECT
    V.id AS Vehiculo_ID,
    V.patente AS Patente,
    MA.nombre AS Marca,
    MO.nombre AS Modelo,
    V.precio_base AS Precio_Base,
    E.nombre AS Estado_Actual
FROM
    Vehiculo V
JOIN
    Modelo MO ON V.id_modelo = MO.id
JOIN
    Marca MA ON MO.id_marca = MA.id
JOIN
    Estado E ON V.id_estado = E.id
WHERE
    E.nombre IN (1, 2, 3, 4);

