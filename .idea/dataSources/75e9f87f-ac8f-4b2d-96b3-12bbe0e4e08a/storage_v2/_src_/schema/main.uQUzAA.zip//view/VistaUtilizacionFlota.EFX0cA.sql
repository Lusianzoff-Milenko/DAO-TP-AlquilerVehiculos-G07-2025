CREATE VIEW VistaUtilizacionFlota AS
SELECT
    V.id AS Vehiculo_ID,
    V.patente AS Patente,
    MA.nombre AS Marca,
    MO.nombre AS Modelo,
    V."año_fabricacion" AS Año,
    COUNT(CO.id) AS Contratos_Totales,
    IFNULL(
        SUM(julianday(DP.fecha_entrega) - julianday(CO.fecha_desde)), 
        0
    ) AS Total_Dias_Alquilados,
    E_Actual.nombre AS Estado_Actual
FROM
    Vehiculo V
JOIN
    Modelo MO ON V.id_modelo = MO.id
JOIN
    Marca MA ON MO.id_marca = MA.id
LEFT JOIN
    DetalleContrato DP ON V.id = DP.id_vehiculo -- Nueva forma de obtener contratos
LEFT JOIN
    Contrato CO ON DP.id_contrato = CO.id AND CO.id_estado = 4 -- Solo contratos 'Ya Entregado' (ID 4)
JOIN
    Estado E_Actual ON V.id_estado = E_Actual.id -- Estado actual del vehículo
GROUP BY
    V.id, V.patente, MA.nombre, MO.nombre, V."año_fabricacion", E_Actual.nombre;

