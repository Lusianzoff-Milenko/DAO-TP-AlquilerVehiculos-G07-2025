CREATE VIEW VistaEmpleadosPuestos AS
SELECT
    E.id AS Empleado_ID,
    P.nombre AS Nombre,
    P.apellido AS Apellido,
    TP.nombre AS Puesto,
    E.fecha_ingreso AS Fecha_Ingreso,
    E.fecha_egreso AS Fecha_Egreso,
    P.telefono AS Teléfono,
    P.mail AS Correo_Electrónico
FROM
    Empleado E
JOIN
    Persona P ON E.id_persona = P.id
JOIN
    TipoPuesto TP ON E.id_tipoPuesto = TP.id;

