CREATE VIEW VistaCantidadFlotaPorModelo AS
SELECT
    mo.nombre AS Modelo,
    ma.nombre AS Marca,
    COUNT(v.id) AS Cantidad
FROM
    Modelo mo
JOIN
    Marca ma ON mo.id_marca = ma.id
LEFT JOIN
    Vehiculo v ON mo.id = v.id_modelo
GROUP BY
    mo.id, mo.nombre, ma.nombre
ORDER BY
    Cantidad DESC;

