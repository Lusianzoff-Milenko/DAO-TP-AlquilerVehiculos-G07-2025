CREATE TRIGGER T_AfterUpdate_DetalleContrato_LiberarVehiculo
AFTER UPDATE ON DetalleContrato
WHEN NEW.fecha_entrega IS NOT NULL AND OLD.fecha_entrega IS NULL
BEGIN
    -- 1. Actualiza el estado del Contrato a 'Finalizado' (ID 4)
    UPDATE Contrato
    SET id_estado = 4
    WHERE id = NEW.id_contrato;

    -- 2. Actualiza el estado del Vehículo a 'Disponible' (ID 1)
    UPDATE Vehiculo
    SET id_estado = 1
    WHERE id = (SELECT id_vehiculo FROM Contrato WHERE id = NEW.id_contrato);
END;

