CREATE VIEW VistaHistorialMantenimiento AS
SELECT
    V.patente AS Patente,
    M.fecha_hora AS Fecha_Mantenimiento,
    M.descripcion AS Descripción,
    M.costo AS Costo,
    E_Mantenimiento.nombre AS Estado_Mantenimiento,
    P.nombre || ' ' || P.apellido AS Empleado_Responsable
FROM
    Mantenimiento M
JOIN
    Vehiculo V ON M.id_vehiculo = V.id
JOIN
    Empleado EM ON M.id_empleado = EM.id
JOIN
    Persona P ON EM.id_persona = P.id
JOIN
    Estado E_Mantenimiento ON M.id_estado = E_Mantenimiento.id
ORDER BY
    V.patente, M.fecha_hora DESC;

