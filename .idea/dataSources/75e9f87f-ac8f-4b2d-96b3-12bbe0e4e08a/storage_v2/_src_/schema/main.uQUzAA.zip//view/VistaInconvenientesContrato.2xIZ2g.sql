CREATE VIEW VistaInconvenientesContrato AS
SELECT
    RI.id AS Inconveniente_ID,
    C.id AS Contrato_ID,
    V.patente AS Patente,
    P_Cliente.nombre || ' ' || P_Cliente.apellido AS Cliente,
    TI.nombre AS Tipo_Inconveniente,
    RI.nombre AS Nombre_Incidente,
    RI.descripcion AS Descripción,
    RI.costo AS Costo_Recargo,
    E.nombre AS Estado_Incidente
FROM
    RegistroInconvenientes RI
JOIN
    Contrato C ON RI.id_contrato = C.id
JOIN
    DetalleContrato DP ON C.id = DP.id_contrato -- Nueva unión para obtener id_vehiculo
JOIN
    Vehiculo V ON DP.id_vehiculo = V.id -- Nueva unión a Vehiculo a través de DetalleContrato
JOIN
    Cliente CL ON C.id_cliente = CL.id
JOIN
    Persona P_Cliente ON CL.id_persona = P_Cliente.id
JOIN
    TipoInconveniente TI ON RI.id_tipoInconveniente = TI.id
JOIN
    Estado E ON RI.id_estado = E.id;

